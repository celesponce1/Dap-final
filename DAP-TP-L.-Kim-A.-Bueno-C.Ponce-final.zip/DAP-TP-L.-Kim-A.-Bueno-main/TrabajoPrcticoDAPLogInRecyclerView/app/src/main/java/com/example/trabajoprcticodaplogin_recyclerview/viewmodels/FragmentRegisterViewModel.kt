package com.example.trabajoprcticodaplogin_recyclerview.viewmodels

import androidx.lifecycle.ViewModel

class FragmentRegisterViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}