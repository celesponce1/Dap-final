package com.example.loginscreen.entities

data class User(
    var username: String,
    var pass: String,
    var email: String,
    var dni: Double
)



