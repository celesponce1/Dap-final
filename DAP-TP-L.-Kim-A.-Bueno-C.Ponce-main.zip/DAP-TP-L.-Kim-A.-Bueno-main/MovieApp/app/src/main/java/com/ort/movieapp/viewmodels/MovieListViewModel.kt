package com.ort.movieapp.viewmodels

import androidx.lifecycle.ViewModel

class MovieListViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}